package uk.ac.cam.cl.dc584.ntpclient;

public class NTPStats {
}
